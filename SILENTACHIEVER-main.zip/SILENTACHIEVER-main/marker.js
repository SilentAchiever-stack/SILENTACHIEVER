let adjective = "mysterious";
console.log(adjective);
let noun = "knight";
console.log(noun);
let verb = "echoed";
console.log(verb);
let place = "castle";
console.log(place);
let adjective2 = "ancient";
console.log(adjective2);
let noun2 = "children";
console.log(noun2);
let firstStory = "once upon a time,\n there was a(n) mysterious knight who love to eat children. \n the knight lived in a castle and had ancients nostrils that blew fire when it was echoed";
console.log(firstStory);


