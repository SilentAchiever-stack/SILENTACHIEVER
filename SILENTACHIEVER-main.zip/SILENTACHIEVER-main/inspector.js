let customerName = "sarah";
let age = 25;
let favouriteProgramming = "html";

let future_age = age + 5;
const intro_message = `my name is ${customerName}, i am currently ${age} years old. i will be ${future_age} in five years, and i'm learning ${favouriteProgramming}`;
console.log(intro_message);