let fortune1 = "your cat will look very cuddly today";
let fortune2 = "the weather will be nice tomorrow";
let fortune3 = "be cautious of your new neigbors";
let fortune4 = "you will find a new hobby soon";
let fortune5 = "it would be wise to avoid the color red today";
let randomNumber = 6;

let selectedFourtune;
if (randomNumber===1){
    selectedFourtune = "your cat will look very cuddly today";
}else if (randomNumber===2){
    seletedFortune = "the weather will be nice tomorrow";
}else if (randomNumber===3){
    selectedFortune = "be cautious of your new neigbors";
}else if (randomNumber===4){
    selectedFortune = "you will find a new hobby soon";
}else if (randomNumber===5){
    selectedFortune = "it would be wise to avoid the color red today";
}else {
    selectedFortune = "please enter a number between 1 and 5";
}
console.log(selectedFortune);
