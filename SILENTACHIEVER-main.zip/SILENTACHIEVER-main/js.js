let updatedCounter = 11;
console.log(++updatedCounter);
console.log(updatedCounter);

let finalScore = 8;
console.log(finalScore++);
console.log(finalScore);

let updatedCoins = 2;
console.log(--updatedCoins);
console.log(updatedCoins);

let newHealth = 7;
console.log(newHealth--);
console.log(newHealth);