/*const mytext = document.getElementById("mytext");
const username = document.getElementById("username");
const mysubmit = document.getElementById("mysubmit");
const resultElement = document.getElementById("resultElement");
let age;
let Username = "";

(mysubmit).onclick = function( ){
    age = mytext.Value; 
    age = Number(age);
    Username = username.Value;

    if (age >= 18){
        resultElement.TextContent = "Hello " + Username + ", you are eligible to login.";

        console.log("Hello " + Username + ", you are eligible to login.");

    }
     else {
        resultElement.TextContent = "Hello " + Username + ", you are not eligible to login.";
    }

}*/
let age = 18;
let Username = "";
function age(){
    console.log("Hello " + Username + ", you are eligible to login.");
}
age();

    else  (age < 18);{
    console.log("Hello " + Username + ", you are not eligible to login.");
    }
