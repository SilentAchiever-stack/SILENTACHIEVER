/*function booWho(){
    return booWho;
    }
    let*/
    let a;
    function booWho(){
        a=true;
        console.log(a);
}
//a=true;
booWho();