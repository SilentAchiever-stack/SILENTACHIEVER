let boowho : Boolean;
function boowho(){
   if(typeof true === Boolean);
   console.log(true);
    return true;
} else{
    return false;

}
booWho();

