console.log("node is running")

let a = 5;
console.log(a)