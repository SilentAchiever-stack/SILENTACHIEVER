let firstResult = 5;
firstResult += 10;
console.log(firstResult);

let secondResult = 8;
secondResult -= 3;
console.log(secondResult);

let thirdResult = 4;
thirdResult += 2;
console.log(thirdResult);

let fourthResult = 4;
fourthResult += 4;
console.log(fourthResult);

let fifthResult = 5;
fifthResult *= 4;
console.log(fifthResult);

let sixthResult = 11;
sixthResult += 11;
console.log(sixthResult);
