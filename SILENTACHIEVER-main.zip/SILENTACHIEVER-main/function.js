let a;
 a=false;
 
    function booWho(){
        if(a ===true){
console.log("true");
       }
       else{
        console.log("false");
       }
       // a=true;
        //console.log(a);
}
//a=true;
booWho();